-- Your Craft: records what Blizzard's web API can't see (bags, banks, auctions, mail, and for
-- Forever/Classic your gear) into SavedVariables. WoW writes that file on logout or /reload;
-- the Your Craft sync program (or the app's Upload button) sends it to your phone.
--
-- One addon for Retail (Midnight), Classic (TBC Anniversary) and Forever. Every API is
-- feature-checked and every scan runs in pcall, so a missing function never breaks the rest.

local ADDON = ...
local f = CreateFrame("Frame")
local leaving = false -- true during logout, exit and loading screens (bags/gold read as empty then)

local REGIONS = { [1] = "us", [2] = "kr", [3] = "eu", [4] = "tw", [5] = "cn" }
local TOC = select(4, GetBuildInfo()) or 0

-- Which game is this? (by client interface number)
local GAME
if TOC >= 100000 then GAME = "retail"
elseif TOC >= 16000 and TOC < 17000 then GAME = "forever"
elseif TOC >= 20000 and TOC < 30000 then GAME = "classic"
elseif TOC < 20000 then GAME = "era"
else GAME = "classic" end

local function now() return time() end

-- Keep the last few errors so problems show up on the server after a sync.
local function note(where, err)
  YourCraftDB.errors = YourCraftDB.errors or {}
  local e = YourCraftDB.errors
  e[#e + 1] = date("%Y-%m-%d %H:%M") .. " " .. GAME .. " " .. where .. ": " .. tostring(err)
  while #e > 20 do table.remove(e, 1) end
end
local function safe(where, fn, ...)
  local ok, err = pcall(fn, ...)
  if not ok then note(where, err) end
end

local function charKey()
  local name, realm = UnitFullName("player")
  realm = realm or (GetNormalizedRealmName and GetNormalizedRealmName()) or GetRealmName()
  return name .. "-" .. realm
end

local function me()
  YourCraftDB.chars = YourCraftDB.chars or {}
  local key = charKey()
  local c = YourCraftDB.chars[key]
  if not c then
    c = {}
    YourCraftDB.chars[key] = c
  end
  local _, classFile = UnitClass("player")
  local race, _, raceId = UnitRace("player")
  c.game = GAME
  c.name = UnitName("player")
  c.realm = GetRealmName()
  c.region = (GetCurrentRegion and REGIONS[GetCurrentRegion()]) or c.region or "us"
  c.class = classFile
  c.race = race
  c.raceId = raceId
  c.sex = UnitSex and UnitSex("player") or nil -- 2 male, 3 female
  c.level = UnitLevel("player")
  c.faction = UnitFactionGroup("player")
  c.guild = (GetGuildInfo and GetGuildInfo("player")) or nil
  return c
end

-- "|cffa335ee|Hitem:12345::...|h[Some Item]|h|r" -> "Some Item"
local function linkName(link)
  return link and link:match("%[(.-)%]") or nil
end

local function itemLevel(link)
  if not link then return nil end
  if C_Item and C_Item.GetDetailedItemLevelInfo then return C_Item.GetDetailedItemLevelInfo(link) end
  if GetDetailedItemLevelInfo then return GetDetailedItemLevelInfo(link) end
  return select(4, GetItemInfo(link))
end

local function itemIcon(id)
  if not id then return nil end
  if C_Item and C_Item.GetItemIconByID then return C_Item.GetItemIconByID(id) end
  return GetItemIcon and GetItemIcon(id) or nil
end

local function itemQuality(linkOrId)
  if not linkOrId then return nil end
  if C_Item and C_Item.GetItemQualityByID then
    local ok, q = pcall(C_Item.GetItemQualityByID, linkOrId)
    if ok and q then return q end
  end
  return select(3, GetItemInfo(linkOrId))
end

-- Container API: modern C_Container where it exists, old globals otherwise.
local function containerSlots(bag)
  if C_Container and C_Container.GetContainerNumSlots then return C_Container.GetContainerNumSlots(bag) or 0 end
  return GetContainerNumSlots and GetContainerNumSlots(bag) or 0
end

local function containerItem(bag, slot)
  if C_Container and C_Container.GetContainerItemInfo then
    local info = C_Container.GetContainerItemInfo(bag, slot)
    if not info or not info.itemID then return nil end
    return info.itemID, info.hyperlink, info.stackCount, info.quality, info.iconFileID
  end
  local icon, count, _, quality, _, _, link, _, _, id = GetContainerItemInfo(bag, slot)
  if not id then return nil end
  return id, link, count, quality, icon
end

local function itemKind(id)
  local f = (C_Item and C_Item.GetItemInfoInstant) or GetItemInfoInstant
  if not f or not id then return nil end
  local ok, _, _, _, equipLoc, _, classID, subClassID = pcall(f, id)
  if not ok then return nil end
  return classID, subClassID, (equipLoc ~= "" and equipLoc or nil)
end

local function scanBags(bagIDs)
  local items = {}
  for _, bag in ipairs(bagIDs) do
    for slot = 1, containerSlots(bag) do
      local id, link, count, quality, icon = containerItem(bag, slot)
      if id then
        local k, sk, e = itemKind(id)
        items[#items + 1] = {
          id = id, n = linkName(link), c = count or 1, q = quality,
          l = itemLevel(link), i = icon, k = k, sk = sk, e = e,
        }
      end
    end
  end
  return items
end

-- Bag index names changed across games; only use the ones this client has.
local function bagList(names, fallback)
  if not Enum or not Enum.BagIndex then return fallback end
  local out = {}
  for _, n in ipairs(names) do
    local id = Enum.BagIndex[n]
    if id then out[#out + 1] = id end
  end
  return #out > 0 and out or fallback
end

local CARRIED = bagList({ "Backpack", "Bag_1", "Bag_2", "Bag_3", "Bag_4", "ReagentBag" }, { 0, 1, 2, 3, 4 })
local CHAR_BANK = bagList({
  "CharacterBankTab_1", "CharacterBankTab_2", "CharacterBankTab_3",
  "CharacterBankTab_4", "CharacterBankTab_5", "CharacterBankTab_6",
  "Bank", "Reagentbank", "BankBag_1", "BankBag_2", "BankBag_3", "BankBag_4", "BankBag_5", "BankBag_6", "BankBag_7",
}, { -1, 5, 6, 7, 8, 9, 10, 11 })
local WARBAND_TABS = {
  "AccountBankTab_1", "AccountBankTab_2", "AccountBankTab_3", "AccountBankTab_4", "AccountBankTab_5",
}

-- Equipped gear (the web API covers Retail; this fills in Forever and Classic).
-- Transmog: the item whose look a slot shows, if it's not the item itself (nil when there's none, or when this game
-- has no transmog), and whether the slot is hidden. Tries the current API, then the older one. tmogApi says which
-- worked, so the app knows whether "no transmog" means none applied or none readable.
local tmogApi
local function transmogOf(slot)
  if not (C_Transmog and C_Transmog.GetSlotVisualInfo and C_TransmogCollection and C_TransmogCollection.GetSourceInfo) then
    tmogApi = "none"; return nil
  end
  local ok, _, _, applied, _, _, _, _, hidden
  if TransmogUtil and TransmogUtil.GetTransmogLocation and Enum and Enum.TransmogType and Enum.TransmogModification then
    ok, _, _, applied, _, _, _, _, hidden = pcall(function()
      return C_Transmog.GetSlotVisualInfo(TransmogUtil.GetTransmogLocation(slot, Enum.TransmogType.Appearance, Enum.TransmogModification.Main))
    end)
    if ok then tmogApi = "location" end
  end
  if not ok then
    ok, _, _, applied, _, _, _, _, hidden = pcall(C_Transmog.GetSlotVisualInfo, slot, LE_TRANSMOG_TYPE_APPEARANCE or 0)
    tmogApi = ok and "slot" or "failed"
  end
  if not ok then return nil end
  if hidden then return nil, true end
  if applied and applied > 0 then
    local okI, info = pcall(C_TransmogCollection.GetSourceInfo, applied)
    if okI and info and info.itemID then return info.itemID end
  end
  return nil
end

local function scanGear()
  if leaving then return end
  local gear = {}
  for slot = 1, 19 do
    local link = GetInventoryItemLink("player", slot)
    if link then
      local id = GetInventoryItemID("player", slot)
      local _, _, e = itemKind(id)
      local d, dm
      if GetInventoryItemDurability then d, dm = GetInventoryItemDurability(slot) end
      local t, hide
      if slot <= 19 then t, hide = transmogOf(slot) end
      gear[#gear + 1] = {
        s = slot, id = id, n = linkName(link), q = GetInventoryItemQuality and GetInventoryItemQuality("player", slot) or itemQuality(link),
        l = itemLevel(link), i = GetInventoryItemTexture("player", slot), e = e, d = d, dm = dm,
        t = (t and t ~= id) and t or nil, h = hide or nil,
      }
    end
  end
  local c = me()
  c.gear = gear
  c.gearAt = now()
  c.tmogApi = tmogApi
  if GetAverageItemLevel then
    local avg, equipped = GetAverageItemLevel()
    c.ilvl = equipped and math.floor(equipped + 0.5) or nil
  end
end

local function scanCarried()
  if leaving then return end
  local c = me()
  c.money = GetMoney()
  -- Gold over time for the app's chart: one point an hour at most (the latest in that hour wins), 400 kept.
  c.moneyLog = c.moneyLog or {}
  local ml, t = c.moneyLog, now()
  local last = ml[#ml]
  if last and t - last.t < 3600 then last.m = c.money
  elseif not last or last.m ~= c.money then ml[#ml + 1] = { t = t, m = c.money } end
  while #ml > 400 do table.remove(ml, 1) end
  c.bags = scanBags(CARRIED)
  c.bagsAt = now()
end

-- Where the character is and what they're doing (also refreshed on a timer while you play).
local function scanLocation()
  if leaving then return end
  local loc = {
    zone = GetRealZoneText and GetRealZoneText() or GetZoneText(),
    sub = GetSubZoneText and GetSubZoneText() or nil,
    hearth = GetBindLocation and GetBindLocation() or nil,
    resting = IsResting and IsResting() or nil,
    mounted = IsMounted and IsMounted() or nil,
    flying = IsFlying and IsFlying() or nil,
    swimming = IsSwimming and IsSwimming() or nil,
    dead = UnitIsDead and UnitIsDead("player") or nil,
    ghost = UnitIsGhost and UnitIsGhost("player") or nil,
    combat = UnitAffectingCombat and UnitAffectingCombat("player") or nil,
    at = now(),
  }
  if loc.sub == "" or loc.sub == loc.zone then loc.sub = nil end
  if IsInInstance then
    local inInstance, kind = IsInInstance()
    if inInstance then loc.instance = kind end
  end
  if C_Map and C_Map.GetBestMapForUnit then
    local mapID = C_Map.GetBestMapForUnit("player")
    if mapID then
      loc.map = mapID
      local info = C_Map.GetMapInfo and C_Map.GetMapInfo(mapID)
      loc.mapName = info and info.name or nil
      local pos = C_Map.GetPlayerMapPosition and C_Map.GetPlayerMapPosition(mapID, "player")
      if pos then
        local x, y = pos:GetXY()
        if x and y and (x > 0 or y > 0) then
          loc.x = math.floor(x * 1000 + 0.5) / 10
          loc.y = math.floor(y * 1000 + 0.5) / 10
        end
      end
    end
  end
  me().loc = loc
end

-- Character sheet stats, from the game itself (works in every game, unlike the web API).
local function scanStats()
  if leaving then return end
  local st = {}
  local function put(k, fn, ...)
    local ok, v = pcall(fn, ...)
    if ok and v ~= nil then st[k] = v end
  end
  put("health", UnitHealthMax, "player")
  put("power", UnitPowerMax, "player")
  if UnitPowerType then
    local _, token = UnitPowerType("player")
    st.powerType = token
  end
  local names = { "str", "agi", "sta", "int", "spi" }
  for i = 1, 5 do
    local ok, _, eff = pcall(UnitStat, "player", i)
    -- Forever can hand back "secret" numbers that can't be compared; skip those instead of erroring.
    local okc, pos = pcall(function() return eff > 0 end)
    if ok and eff and okc and pos then st[names[i]] = eff end
  end
  if UnitArmor then local ok, _, eff = pcall(UnitArmor, "player"); if ok then st.armor = eff end end
  if GetCritChance then put("crit", GetCritChance) end
  if GetSpellCritChance then put("spellCrit", GetSpellCritChance, 2) end
  if GetRangedCritChance then put("rangedCrit", GetRangedCritChance) end
  if GetHaste then put("haste", GetHaste) end
  if GetMasteryEffect then put("mastery", GetMasteryEffect) end
  if GetCombatRatingBonus and CR_VERSATILITY_DAMAGE_DONE then
    local ok, v = pcall(GetCombatRatingBonus, CR_VERSATILITY_DAMAGE_DONE)
    if ok and v then st.vers = v + ((GetVersatilityBonus and GetVersatilityBonus(CR_VERSATILITY_DAMAGE_DONE)) or 0) end
  end
  if GetDodgeChance then put("dodge", GetDodgeChance) end
  if GetParryChance then put("parry", GetParryChance) end
  if GetBlockChance then put("block", GetBlockChance) end
  if UnitAttackPower then
    local ok, base, pos, neg = pcall(UnitAttackPower, "player")
    if ok and base then st.ap = base + (pos or 0) + (neg or 0) end
  end
  if UnitRangedAttackPower then
    local ok, base, pos, neg = pcall(UnitRangedAttackPower, "player")
    if ok and base and base > 0 then st.rap = base + (pos or 0) + (neg or 0) end
  end
  if GetSpellBonusDamage then put("sp", GetSpellBonusDamage, 2) end
  if GetSpellBonusHealing then put("heal", GetSpellBonusHealing) end
  if GetHitModifier then put("hit", GetHitModifier) end
  if GetSpellHitModifier then put("spellHit", GetSpellHitModifier) end
  if GetManaRegen then
    local ok, base, casting = pcall(GetManaRegen)
    if ok and base then st.mp5 = math.floor(base * 5 + 0.5); st.mp5c = math.floor((casting or 0) * 5 + 0.5) end
  end
  local c = me()
  c.stats = st
  c.statsAt = now()
end

local bankOpen = false

local function scanBank()
  if not bankOpen then return end
  local c = me()
  c.bank = scanBags(CHAR_BANK)
  c.bankAt = now()

  -- Warband bank (Retail only) is shared by every character on the Battle.net account.
  if not Enum or not Enum.BagIndex or not Enum.BagIndex.AccountBankTab_1 then return end
  local tabs = {}
  for i, n in ipairs(WARBAND_TABS) do
    local id = Enum.BagIndex[n]
    if id and containerSlots(id) > 0 then
      tabs[#tabs + 1] = { tab = i, items = scanBags({ id }) }
    end
  end
  if #tabs > 0 then
    YourCraftDB.warband = { tabs = tabs, at = now(), region = c.region }
    if C_Bank and C_Bank.FetchDepositedMoney and Enum.BankType and Enum.BankType.Account then
      YourCraftDB.warband.money = C_Bank.FetchDepositedMoney(Enum.BankType.Account)
    end
  end
end

-- Retail-style auction house (C_AuctionHouse).
local function scanAuctionsModern()
  local list = C_AuctionHouse.GetOwnedAuctions()
  if not list then return end
  local out = {}
  for _, a in ipairs(list) do
    local id = a.itemKey and a.itemKey.itemID
    out[#out + 1] = {
      id = id, n = linkName(a.itemLink), c = a.quantity or 1, q = itemQuality(a.itemLink or id),
      i = itemIcon(id), buyout = a.buyoutAmount, bid = a.bidAmount,
      sold = a.status == 1 or nil, left = a.timeLeftSeconds,
    }
  end
  local c = me()
  c.auctions = out
  c.auctionsAt = now()
end

-- Classic-style auction house (owner list).
local TIME_LEFT = { [1] = 30 * 60, [2] = 2 * 3600, [3] = 12 * 3600, [4] = 48 * 3600 }
local function scanAuctionsClassic()
  local n = GetNumAuctionItems("owner") or 0
  local out = {}
  for i = 1, n do
    local name, texture, count, quality, _, _, _, minBid, _, buyout, bidAmount, _, _, _, _, saleStatus, itemId =
      GetAuctionItemInfo("owner", i)
    if name then
      out[#out + 1] = {
        id = itemId, n = name, c = count or 1, q = quality, i = texture,
        buyout = (buyout and buyout > 0) and buyout or nil,
        bid = (bidAmount and bidAmount > 0) and bidAmount or minBid,
        sold = saleStatus == 1 or nil,
        left = TIME_LEFT[GetAuctionItemTimeLeft("owner", i) or 0],
      }
    end
  end
  local c = me()
  c.auctions = out
  c.auctionsAt = now()
end

local function scanMail()
  local count = GetInboxNumItems()
  local out = {}
  for i = 1, count do
    local _, _, sender, subject, money, cod, daysLeft, hasItem = GetInboxHeaderInfo(i)
    local items
    if hasItem then
      items = {}
      for a = 1, ATTACHMENTS_MAX_RECEIVE or 16 do
        local name, itemID, texture, itemCount, quality = GetInboxItem(i, a)
        if name then
          items[#items + 1] = { id = itemID, n = name, c = itemCount or 1, q = quality, i = texture }
        end
      end
    end
    out[#out + 1] = {
      from = sender,
      subject = subject,
      money = (money and money > 0) and money or nil,
      cod = (cod and cod > 0) and cod or nil,
      expires = daysLeft and (now() + math.floor(daysLeft * 86400)) or nil,
      items = items,
    }
  end
  local c = me()
  c.mail = out
  c.mailAt = now()
end

-- Bursts of events: coalesce them.
local pending = {}
local function soon(key, fn)
  if pending[key] then return end
  pending[key] = true
  C_Timer.After(1, function()
    pending[key] = nil
    safe(key, fn)
  end)
end



-- ---------- levelling, supplies, talents, reputation, pet (addon 2.5) ----------
-- XP, rested XP and a short log of XP over time (the app works out XP per hour and time to level from it).
local function scanLevel()
  local c = me()
  local x, m = UnitXP("player"), UnitXPMax("player")
  local r = (GetXPExhaustion and GetXPExhaustion()) or 0
  c.xp = { x = x, m = m, r = r, rest = IsResting and IsResting() or false, at = now() }
  c.xpLog = c.xpLog or {}
  local last = c.xpLog[#c.xpLog]
  local lvl = UnitLevel("player")
  if not last or last.x ~= x or last.l ~= lvl then
    c.xpLog[#c.xpLog + 1] = { t = now(), l = lvl, x = x, m = m }
    while #c.xpLog > 300 do table.remove(c.xpLog, 1) end
  end
end

-- Time played, asked for once per login without printing it in chat.
local playedAsked, playedHidden = false, nil
local function askPlayed()
  if playedAsked or not RequestTimePlayed then return end
  playedAsked = true
  if ChatFrame_DisplayTimePlayed then playedHidden = ChatFrame_DisplayTimePlayed; ChatFrame_DisplayTimePlayed = function() end end
  RequestTimePlayed()
  C_Timer.After(10, function() if playedHidden then ChatFrame_DisplayTimePlayed = playedHidden; playedHidden = nil end end)
end
local function gotPlayed(total, thisLevel)
  local c = me()
  c.played = { t = total, l = thisLevel, at = now() }
  if playedHidden then ChatFrame_DisplayTimePlayed = playedHidden; playedHidden = nil end
end

-- Durability, ammo and free bag space.
local function scanSupplies()
  if leaving then return end
  local c = me()
  local worst, low = 1, {}
  for slot = 1, 19 do
    local cur, max = GetInventoryItemDurability and GetInventoryItemDurability(slot)
    if cur and max and max > 0 then
      local pct = cur / max
      if pct < worst then worst = pct end
      if pct < 0.3 then low[#low + 1] = slot end
    end
  end
  local free, size = 0, 0
  for _, bag in ipairs(CARRIED) do
    local n = containerSlots(bag)
    local f, kind = 0, 0
    if C_Container and C_Container.GetContainerNumFreeSlots then f, kind = C_Container.GetContainerNumFreeSlots(bag)
    elseif GetContainerNumFreeSlots then f, kind = GetContainerNumFreeSlots(bag) end
    if (kind or 0) == 0 then free = free + (f or 0); size = size + n end
  end
  local ammo
  local aid = GetInventoryItemID and GetInventoryItemID("player", 0)
  if aid and aid > 0 then
    ammo = { id = aid, c = GetInventoryItemCount("player", 0), n = linkName(GetInventoryItemLink("player", 0)) }
  end
  c.supply = { dur = math.floor(worst * 100 + 0.5), low = low, free = free, size = size, ammo = ammo, at = now() }
end

-- Talents (Forever and Classic use the classic trees). Each tab: name, icon, points, and every talent.
local function scanTalents()
  if not GetNumTalentTabs or not GetTalentInfo then return end
  local c = me()
  local tabs = {}
  for t = 1, GetNumTalentTabs() do
    local r = { GetTalentTabInfo(t) }
    local name, icon, pts
    if type(r[1]) == "number" and type(r[2]) == "string" then name, icon, pts = r[2], r[4], r[5]
    else name, icon, pts = r[1], r[2], r[3] end
    local list = {}
    for i = 1, (GetNumTalents and GetNumTalents(t) or 0) do
      local n, ic, tier, col, rank, max = GetTalentInfo(t, i)
      if n then list[#list + 1] = { n = n, i = ic, r = tier, c = col, k = rank or 0, m = max or 1 } end
    end
    tabs[#tabs + 1] = { n = name, i = icon, p = pts or 0, t = list }
  end
  local unspent = (UnitCharacterPoints and UnitCharacterPoints("player")) or (GetUnspentTalentPoints and GetUnspentTalentPoints()) or 0
  c.talents = { tabs = tabs, free = unspent or 0, at = now() }
end

-- Reputation: every faction you've met, headers opened while reading and closed again after.
local function scanReps()
  local c = me()
  local out = {}
  if GetNumFactions and GetFactionInfo then
    local opened = {}
    local i = 1
    while i <= GetNumFactions() do
      local name, _, _, _, _, _, _, _, isHeader, isCollapsed = GetFactionInfo(i)
      if isHeader and isCollapsed and ExpandFactionHeader then opened[#opened + 1] = name; ExpandFactionHeader(i) end
      i = i + 1
    end
    for j = 1, GetNumFactions() do
      local name, _, standing, lo, hi, val, _, _, isHeader, _, hasRep, _, _, id = GetFactionInfo(j)
      if name then out[#out + 1] = { n = name, id = id, s = standing, lo = lo, hi = hi, v = val, h = (isHeader and not hasRep) or nil } end
    end
    if #opened > 0 and CollapseFactionHeader then
      for j = GetNumFactions(), 1, -1 do
        local name, _, _, _, _, _, _, _, isHeader = GetFactionInfo(j)
        if isHeader then for _, o in ipairs(opened) do if o == name then CollapseFactionHeader(j) end end end
      end
    end
  elseif C_Reputation and C_Reputation.GetNumFactions and C_Reputation.GetFactionDataByIndex then
    for j = 1, C_Reputation.GetNumFactions() do
      local f = C_Reputation.GetFactionDataByIndex(j)
      if f then out[#out + 1] = { n = f.name, id = f.factionID, s = f.reaction, lo = f.currentReactionThreshold, hi = f.nextReactionThreshold,
        v = f.currentStanding, h = (f.isHeader and not f.isHeaderWithRep) or nil } end
    end
  end
  if #out > 0 then c.reps = out; c.repsAt = now() end
end

-- Hunter pet: kept from the last time it was out.
local function scanPet()
  if not UnitExists or not UnitExists("pet") then return end
  local _, cls = UnitClass("player")
  if cls ~= "HUNTER" then return end
  local c = me()
  local p = { n = UnitName("pet"), l = UnitLevel("pet"), fam = UnitCreatureFamily and UnitCreatureFamily("pet"), at = now() }
  if GetPetHappiness then local h = GetPetHappiness(); p.happy = h end
  if GetPetLoyalty then local ok, lo = pcall(GetPetLoyalty); if ok then p.loyal = lo end end
  if GetPetExperience then local cur, nxt = GetPetExperience(); p.x, p.xm = cur, nxt end
  if GetPetTrainingPoints then local tot, spent = GetPetTrainingPoints(); p.tp, p.tps = tot, spent end
  local spells = {}
  local book = BOOKTYPE_PET or "pet"
  local num = HasPetSpells and HasPetSpells()
  if num and GetSpellBookItemName then
    for i = 1, num do
      local n, sub = GetSpellBookItemName(i, book)
      if n then spells[#spells + 1] = { n = n, r = sub } end
    end
  end
  p.spells = spells
  c.pet = p
end

-- Which gear slot every craftable item goes in (for "upgrades you can make"); worked out once per addon version.
local function scanCraftSlots()
  if not YourCraftCrafts then return end
  local c = me()
  if c.craftSlotsV == 2 then return end
  local slots = {}
  for _, id in ipairs(YourCraftCrafts) do
    local _, _, e = itemKind(id)
    if e and e ~= "INVTYPE_NON_EQUIP_IGNORE" and e ~= "INVTYPE_BAG" then slots[tostring(id)] = e end
  end
  c.craftSlots = slots
  c.craftSlotsV = 2 -- 2: dungeon loot too
end

-- Spells in the spellbook (ids of every rank shown), so the app's trainer guide knows what's already learned.
local function scanSpells()
  local c = me()
  local ids = {}
  local function add(id) if id and id > 0 then ids[#ids + 1] = id end end
  if C_SpellBook and C_SpellBook.GetNumSpellBookSkillLines and C_SpellBook.GetSpellBookItemInfo and Enum and Enum.SpellBookSpellBank then
    for t = 1, C_SpellBook.GetNumSpellBookSkillLines() do
      local info = C_SpellBook.GetSpellBookSkillLineInfo(t)
      if info and not info.shouldHide then
        for i = info.itemIndexOffset + 1, info.itemIndexOffset + info.numSpellBookItems do
          local it = C_SpellBook.GetSpellBookItemInfo(i, Enum.SpellBookSpellBank.Player)
          if it and it.itemType == Enum.SpellBookItemType.Spell then add(it.actionID or it.spellID) end
        end
      end
    end
  elseif GetNumSpellTabs and GetSpellTabInfo and GetSpellBookItemInfo then
    for t = 1, GetNumSpellTabs() do
      local _, _, offset, num = GetSpellTabInfo(t)
      for i = offset + 1, offset + num do
        local kind, id = GetSpellBookItemInfo(i, BOOKTYPE_SPELL or "spell")
        if kind == "SPELL" then add(id) end
      end
    end
  end
  if #ids > 0 then c.spells = ids; c.spellsAt = now() end
end

-- Recipes (Forever): for each profession this character has, which recipes it knows and every recipe's name,
-- read from the game so the app's profession guide can name them. Ids come from YourCraftRecipes.lua.
local PROF_LINES = { [171] = { "Alchemy", 2259 }, [164] = { "Blacksmithing", 2018 }, [185] = { "Cooking", 2550 },
  [333] = { "Enchanting", 7411 }, [202] = { "Engineering", 4036 }, [129] = { "First Aid", 3273 },
  [356] = { "Fishing", 7620 }, [182] = { "Herbalism", 9134 }, [165] = { "Leatherworking", 2108 },
  [186] = { "Mining", 2575 }, [393] = { "Skinning", 8613 }, [197] = { "Tailoring", 3908 } }
local function spellName(id)
  if C_Spell and C_Spell.GetSpellInfo then
    local info = C_Spell.GetSpellInfo(id)
    return info and info.name
  end
  return GetSpellInfo and (GetSpellInfo(id))
end
local function knowsSpell(id)
  if C_SpellBook and C_SpellBook.IsSpellKnown and Enum and Enum.SpellBookSpellBank then
    local ok, r = pcall(C_SpellBook.IsSpellKnown, id, Enum.SpellBookSpellBank.Player)
    if ok and r ~= nil then return r end
  end
  if IsPlayerSpell then return IsPlayerSpell(id) end
  return IsSpellKnown and IsSpellKnown(id)
end
local function scanRecipes()
  if GAME ~= "forever" or not YourCraftRecipeIds then return end
  local c = me()
  local have = {}
  for _, sk in ipairs(c.skills or {}) do have[sk.n] = true end
  c.recipes = c.recipes or {}
  c.rnames = c.rnames or {}
  for line, ids in pairs(YourCraftRecipeIds) do
    local p = PROF_LINES[line]
    local local_name = p and spellName(p[2])
    if p and (have[p[1]] or (local_name and have[local_name])) then
      local known = {}
      for _, id in ipairs(ids) do
        local n = spellName(id)
        if n then c.rnames[id] = n end
        if knowsSpell(id) then known[#known + 1] = id end
      end
      local r = c.recipes[p[1]] or {}
      r.k = known
      c.recipes[p[1]] = r
    elseif p then
      c.recipes[p[1]] = nil
    end
  end
  c.recipesAt = now()
end
-- With a profession window open, note every recipe it lists by name (a backup for the known check above).
local function scanTradeWindow()
  if GAME ~= "forever" or not GetTradeSkillLine or not GetNumTradeSkills then return end
  local line = GetTradeSkillLine()
  if not line or line == "UNKNOWN" then return end
  local key
  for _, p in pairs(PROF_LINES) do if p[1] == line or spellName(p[2]) == line then key = p[1] end end
  if not key then return end
  local c = me()
  local seen, col = {}, {}
  local COL = { optimal = "o", medium = "y", easy = "g", trivial = "t" }
  for i = 1, GetNumTradeSkills() do
    local name, kind = GetTradeSkillInfo(i)
    if name and kind ~= "header" and kind ~= "subheader" then
      seen[#seen + 1] = name
      if COL[kind] then col[name] = COL[kind] end -- the colour the game shows: how likely a skill point is
    end
  end
  c.recipes = c.recipes or {}
  c.recipes[key] = c.recipes[key] or {}
  c.recipes[key].seen = seen
  c.recipes[key].col = col
  c.recipes[key].colAt = now()
end

-- Professions and other skills (Fishing, Enchanting, Tailoring, weapon skills...) with rank / max.
-- Retail: GetProfessions(). Classic and Forever: the old skill list, every header opened while we
-- read it and closed again afterwards so the player's Skills window looks the same.
local function scanSkills()
  local c = me()
  local out = {}
  if GetProfessions and GetProfessionInfo then
    local p1, p2, arch, fish, cook = GetProfessions()
    local function add(idx, group)
      if not idx then return end
      local name, icon, rank, maxRank = GetProfessionInfo(idx)
      if name then out[#out + 1] = { n = name, r = rank, m = maxRank, i = icon, g = group } end
    end
    add(p1, "primary"); add(p2, "primary")
    add(fish, "secondary"); add(cook, "secondary"); add(arch, "secondary")
  elseif GetNumSkillLines and GetSkillLineInfo then
    local opened = {}
    local i = 1
    while i <= GetNumSkillLines() do
      local name, isHeader, isExpanded = GetSkillLineInfo(i)
      if isHeader and not isExpanded and ExpandSkillHeader then
        opened[#opened + 1] = name
        ExpandSkillHeader(i)
      end
      i = i + 1
    end
    local group
    for j = 1, GetNumSkillLines() do
      local name, isHeader, _, rank, temp, mod, maxRank = GetSkillLineInfo(j)
      if isHeader then
        group = name
      elseif name then
        out[#out + 1] = { n = name, r = rank, m = maxRank, b = ((temp or 0) + (mod or 0)) ~= 0 and ((temp or 0) + (mod or 0)) or nil, g = group }
      end
    end
    -- close what we opened (from the bottom, so the indexes stay right)
    if CollapseSkillHeader and #opened > 0 then
      local wanted = {}
      for _, n in ipairs(opened) do wanted[n] = true end
      for j = GetNumSkillLines(), 1, -1 do
        local name, isHeader, isExpanded = GetSkillLineInfo(j)
        if isHeader and isExpanded and wanted[name] then CollapseSkillHeader(j) end
      end
    end
  end
  if #out > 0 then
    c.skills = out
    c.skillsAt = now()
  end
end

f:SetScript("OnEvent", function(_, event, arg1, arg2)
  if event == "ADDON_LOADED" then
    if arg1 ~= ADDON then return end
    YourCraftDB = YourCraftDB or {}
    YourCraftDB.version = 2
    YourCraftDB.game = GAME
    YourCraftDB.toc = TOC
  elseif event == "PLAYER_ENTERING_WORLD" then
    leaving = false
    safe("carried", scanCarried)
    safe("gear", scanGear)
    C_Timer.After(2, function() safe("location", scanLocation); safe("stats", scanStats); safe("skills", scanSkills); safe("spells", scanSpells); safe("recipes", scanRecipes)
      safe("level", scanLevel); safe("supplies", scanSupplies); safe("talents", scanTalents); safe("reps", scanReps)
      safe("pet", scanPet); safe("craft slots", scanCraftSlots) end)
    C_Timer.After(6, function() safe("played", askPlayed) end)
    if not YourCraftTicker and C_Timer.NewTicker then
      -- Keep location/stats fresh so the last save before logout is accurate.
      YourCraftTicker = C_Timer.NewTicker(20, function() safe("location", scanLocation); safe("stats", scanStats) end)
    end
  elseif event == "ZONE_CHANGED" or event == "ZONE_CHANGED_NEW_AREA" or event == "ZONE_CHANGED_INDOORS"
      or event == "PLAYER_UPDATE_RESTING" or event == "PLAYER_DEAD" or event == "PLAYER_ALIVE" or event == "PLAYER_UNGHOST" then
    soon("location", scanLocation)
    if event == "PLAYER_UPDATE_RESTING" then soon("level", scanLevel) end
  elseif event == "UNIT_STATS" or event == "PLAYER_LEVEL_UP" or event == "COMBAT_RATING_UPDATE" then
    soon("stats", scanStats)
  elseif event == "PLAYER_MONEY" then
    safe("carried", scanCarried)
  elseif event == "SKILL_LINES_CHANGED" or event == "TRADE_SKILL_SHOW" or event == "TRADE_SKILL_UPDATE" or event == "CHAT_MSG_SKILL" then
    soon("skills", function() scanSkills(); scanRecipes(); if event == "TRADE_SKILL_SHOW" or event == "TRADE_SKILL_UPDATE" then scanTradeWindow() end end)
  elseif event == "PLAYER_XP_UPDATE" or event == "UPDATE_EXHAUSTION" then
    soon("level", scanLevel)
  elseif event == "TIME_PLAYED_MSG" then
    safe("played", gotPlayed, arg1, arg2)
  elseif event == "UPDATE_INVENTORY_DURABILITY" then
    soon("supplies", scanSupplies)
  elseif event == "CHARACTER_POINTS_CHANGED" or event == "PLAYER_TALENT_UPDATE" or event == "SPELLS_CHANGED_TALENTS" then
    soon("talents", scanTalents)
  elseif event == "UPDATE_FACTION" then
    soon("reps", scanReps)
  elseif event == "UNIT_PET" or event == "PET_UI_UPDATE" or event == "UNIT_HAPPINESS" or event == "UNIT_PET_EXPERIENCE" or event == "PET_BAR_UPDATE" then
    soon("pet", scanPet)
  elseif event == "SPELLS_CHANGED" or event == "LEARNED_SPELL_IN_TAB" then
    soon("spells", function() scanSpells(); scanRecipes() end)
  elseif event == "PLAYER_EQUIPMENT_CHANGED" then
    soon("gear", function() scanGear(); scanStats() end)
  elseif event == "TRANSMOGRIFY_SUCCESS" or event == "TRANSMOGRIFY_CLOSE" then
    soon("gear", function() scanGear(); scanStats() end)
  elseif event == "BAG_UPDATE_DELAYED" or event == "BAG_UPDATE" then
    soon("bags", function()
      scanCarried()
      scanSupplies()
      scanBank()
    end)
  elseif event == "BANKFRAME_OPENED" then
    bankOpen = true
    C_Timer.After(0.5, function() safe("bank", scanBank) end)
  elseif event == "BANKFRAME_CLOSED" then
    safe("bank", scanBank)
    bankOpen = false
  elseif event == "PLAYERBANKSLOTS_CHANGED" or event == "PLAYERACCOUNTBANKSLOTS_CHANGED" or event == "PLAYERREAGENTBANKSLOTS_CHANGED" then
    soon("bank", scanBank)
  elseif event == "AUCTION_HOUSE_SHOW" then
    if C_AuctionHouse and C_AuctionHouse.QueryOwnedAuctions then
      safe("ah query", C_AuctionHouse.QueryOwnedAuctions, {})
    elseif GetNumAuctionItems then
      C_Timer.After(1, function() safe("auctions", scanAuctionsClassic) end)
    end
  elseif event == "OWNED_AUCTIONS_UPDATED" then
    safe("auctions", scanAuctionsModern)
  elseif event == "AUCTION_OWNED_LIST_UPDATE" then
    soon("auctions", scanAuctionsClassic)
  elseif event == "MAIL_INBOX_UPDATE" then
    soon("mail", scanMail)
  elseif event == "PLAYER_LEAVING_WORLD" then
    leaving = true
  elseif event == "PLAYER_LOGOUT" then
    -- Don't scan here: the game has already emptied bags/gold. Everything is current from earlier events.
    leaving = true
    YourCraftDB.savedAt = now()
  end
end)

for _, e in ipairs({
  "ADDON_LOADED", "PLAYER_ENTERING_WORLD", "PLAYER_MONEY", "PLAYER_EQUIPMENT_CHANGED",
  "BAG_UPDATE_DELAYED", "BANKFRAME_OPENED", "BANKFRAME_CLOSED",
  "PLAYERBANKSLOTS_CHANGED", "PLAYERACCOUNTBANKSLOTS_CHANGED", "PLAYERREAGENTBANKSLOTS_CHANGED",
  "AUCTION_HOUSE_SHOW", "OWNED_AUCTIONS_UPDATED", "AUCTION_OWNED_LIST_UPDATE",
  "MAIL_INBOX_UPDATE", "PLAYER_LEAVING_WORLD", "PLAYER_LOGOUT",
  "ZONE_CHANGED", "ZONE_CHANGED_NEW_AREA", "ZONE_CHANGED_INDOORS", "PLAYER_UPDATE_RESTING",
  "PLAYER_DEAD", "PLAYER_ALIVE", "PLAYER_UNGHOST", "UNIT_STATS", "PLAYER_LEVEL_UP", "COMBAT_RATING_UPDATE",
  "SKILL_LINES_CHANGED", "TRADE_SKILL_SHOW", "TRADE_SKILL_UPDATE", "CHAT_MSG_SKILL",
  "SPELLS_CHANGED", "LEARNED_SPELL_IN_TAB",
  "PLAYER_XP_UPDATE", "UPDATE_EXHAUSTION", "TIME_PLAYED_MSG", "UPDATE_INVENTORY_DURABILITY",
  "CHARACTER_POINTS_CHANGED", "PLAYER_TALENT_UPDATE", "UPDATE_FACTION",
  "UNIT_PET", "PET_UI_UPDATE", "UNIT_HAPPINESS", "UNIT_PET_EXPERIENCE", "PET_BAR_UPDATE",
  "TRANSMOGRIFY_SUCCESS", "TRANSMOGRIFY_CLOSE",
}) do
  pcall(f.RegisterEvent, f, e) -- skip any event this client doesn't have
end

local function scanAll()
  safe("carried", scanCarried)
  safe("gear", scanGear)
  safe("location", scanLocation)
  safe("stats", scanStats)
  safe("skills", scanSkills)
  safe("spells", scanSpells)
  safe("recipes", scanRecipes)
  safe("level", scanLevel)
  safe("supplies", scanSupplies)
  safe("talents", scanTalents)
  safe("reps", scanReps)
  safe("pet", scanPet)
end

-- Save now: WoW only writes addon data to disk on logout or a UI reload, so this scans everything and reloads.
local function saveNow()
  if InCombatLockdown and InCombatLockdown() then
    print("|cffe8b54aYour Craft|r: can't save in combat. Try again in a moment.")
    return
  end
  scanAll()
  YourCraftDB.savedAt = now()
  ReloadUI()
end

-- A very small "Save" button by the minimap. Right-drag to move it; /yc hide and /yc show.
local saveBtn
local function makeSaveButton()
  if saveBtn or not YourCraftDB then return end
  local b = CreateFrame("Button", "YourCraftSaveButton", UIParent, "UIPanelButtonTemplate")
  b:SetSize(42, 18)
  b:SetText("Save")
  if b.Text then b.Text:SetFontObject("GameFontNormalSmall") end
  b:SetFrameStrata("MEDIUM")
  b:SetClampedToScreen(true)
  b:SetMovable(true)
  local p = YourCraftDB.saveBtn
  if p and p.x then b:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", p.x, p.y)
  elseif Minimap then b:SetPoint("TOPRIGHT", Minimap, "BOTTOMRIGHT", 0, -4)
  else b:SetPoint("TOPRIGHT", UIParent, "TOPRIGHT", -20, -200) end
  b:RegisterForClicks("LeftButtonUp")
  b:RegisterForDrag("RightButton")
  b:SetScript("OnDragStart", function(self) self:StartMoving() end)
  b:SetScript("OnDragStop", function(self)
    self:StopMovingOrSizing()
    YourCraftDB.saveBtn = { x = self:GetLeft(), y = self:GetBottom() }
  end)
  b:SetScript("OnClick", saveNow)
  b:SetScript("OnEnter", function(self)
    GameTooltip:SetOwner(self, "ANCHOR_BOTTOMLEFT")
    GameTooltip:AddLine("Your Craft")
    GameTooltip:AddLine("Save now: sends your character to the app.", 1, 1, 1)
    GameTooltip:AddLine("The screen flashes for a second. Right-drag to move.", .7, .7, .7)
    GameTooltip:Show()
  end)
  b:SetScript("OnLeave", function() GameTooltip:Hide() end)
  if YourCraftDB.saveBtnHidden then b:Hide() end
  saveBtn = b
end
local function tryButton(n)
  if YourCraftDB then return safe("save button", makeSaveButton) end
  if n < 30 then C_Timer.After(1, function() tryButton(n + 1) end) end
end
C_Timer.After(1, function() tryButton(1) end)

SLASH_YOURCRAFT1 = "/yourcraft"
SLASH_YOURCRAFT2 = "/yc"
SlashCmdList.YOURCRAFT = function(msg)
  msg = (msg or ""):lower():match("^%s*(.-)%s*$")
  if msg == "save" then return saveNow() end
  if msg == "hide" or msg == "show" then
    YourCraftDB.saveBtnHidden = (msg == "hide")
    safe("save button", makeSaveButton)
    if saveBtn then saveBtn:SetShown(msg == "show") end
    return print("|cffe8b54aYour Craft|r: Save button " .. (msg == "show" and "shown." or "hidden. /yc show brings it back."))
  end
  scanAll()
  local errs = YourCraftDB.errors and #YourCraftDB.errors or 0
  print("|cffe8b54aYour Craft|r (" .. GAME .. "): saved. Press Save (or /yc save) to send it to your phone now."
    .. (errs > 0 and (" |cffff6060" .. errs .. " error(s) logged.|r") or ""))
end
